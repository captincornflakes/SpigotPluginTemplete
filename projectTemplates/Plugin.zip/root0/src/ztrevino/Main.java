package ${IJ_BASE_PACKAGE};

import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin {

    @Override
    public void onEnable(){
        //Fired when the server enables the plugin

        this.saveDefaultConfig();
        this.getConfig();
        saveConfig();

    }

    @Override
    public void onDisable(){
        //Fired when the server stops and disables all plugins
    }

}
